#!/usr/bin/env python3
"""A chat front end for the agent, for the demo: person -> app -> LLM -> tools -> back.

A thin Streamlit page over `agent_app.py`; it adds no logic of its own. Under every
answer it shows the sources the tools cited, the photo behind each scanned source (from
the database, hash-checked; incident forms only with the person and signature removed),
and an expander with what happened on the
way: each model call (with its time) and each tool call (with the arguments the model
sent, whether the tool refused, and how long it took). That expander is the live view of
the path a question takes.

The conversation survives a restart (#5): its id is in the page's link (?session=...), and
after every answer it is saved through sessions.py (a table only the agent_sessions user can
touch). Opening the link again, after a redeploy or on another device, reloads it, so a
follow-up still has the earlier context. If the store isn't set up or is down, the sidebar
says conversations aren't being saved and the page carries on in memory. The sidebar also
lists the newest saved conversations (RECENT), above Spend; clicking one opens it here.

Usage
    streamlit run scripts/agent_ui.py

Needs the same .env as agent_app.py (AGENT_DB_*, OPENAI_API_KEY, OPENAI_BASE_URL) and
`streamlit` (pip install streamlit; with uv: uv add streamlit).
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import agent_app as app  # noqa: E402

EXAMPLES = [
    "Is CNC-02 running differently now?",
    "What oil does CNC-03 take?",
    "What is the procedure for entering the blasting chamber?",
    "What is the welding SOP?",
    "How many incidents in 2025 were severity 4 or worse?",
    "What is the name of employee EMP015?",          # the guardrail: a PDPA refusal, in code
]


class TraceHandler(logging.Handler):
    """Collects the JSON events agent_app logs during one question."""

    def __init__(self):
        super().__init__()
        self.events: list[dict] = []

    def emit(self, record):
        try:
            self.events.append(json.loads(record.getMessage()))
        except ValueError:
            pass


# The same file agent_app.py writes. AGENT_LOG_FILE=off turns the file off (a hosted
# container's disk is temporary; its stderr goes to the platform's logs instead).
LOG_FILE = os.environ.get("AGENT_LOG_FILE", "logs/agent_app.jsonl")
_file_handler: logging.Handler | None = None
_stderr_handler: logging.Handler | None = None


def _shared_file_handler() -> logging.Handler:
    """One file handler for the whole page process (not one per question)."""
    global _file_handler
    if _file_handler is None:
        Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        _file_handler = logging.FileHandler(LOG_FILE)
        _file_handler.setFormatter(logging.Formatter("%(message)s"))
    return _file_handler


def trace_logger(log_to_file: bool = False) -> tuple[logging.Logger, TraceHandler]:
    """A logger for one question: feeds the on-page table, and with `log_to_file`
    also appends the same JSON lines to logs/agent_app.jsonl."""
    handler = TraceHandler()
    lg = logging.getLogger(f"agent_ui.{id(handler)}")
    lg.setLevel(logging.INFO)
    lg.propagate = False
    lg.addHandler(handler)
    if log_to_file:
        global _stderr_handler
        if _stderr_handler is None:           # Cloud Logging and similar read stderr
            _stderr_handler = logging.StreamHandler(sys.stderr)
            _stderr_handler.setFormatter(logging.Formatter("%(message)s"))
        lg.addHandler(_stderr_handler)
        if LOG_FILE and LOG_FILE.lower() != "off":
            lg.addHandler(_shared_file_handler())
    return lg, handler


def photo_items(db, raw_sources: list[dict], fetch=None) -> list[dict]:
    """The photos to show under an answer: one per image source, fetched from the
    database and hash-checked (agent_tools.fetch_image). Forms come only redacted. A source
    whose photo isn't stored, or fails the check, gets a note instead of a picture.
    The model never produces these: they come from the tools' sources."""
    import agent_tools as at

    fetch = fetch or at.fetch_image
    items = []
    for s in at.image_sources(raw_sources):
        img = fetch(db, s["sha256"])
        what = s.get("what") or "Scan"
        if img is None:
            items.append({"note": f"{what}: {s.get('file')} - photo not available here."})
            continue
        caption = f"{what}: {img['source_file']}"
        if img["variant"] == "redacted":
            caption += " (person and signature removed)"
        items.append({"bytes": img["bytes"], "mime": img["mime"], "caption": caption,
                      "file": img["source_file"]})
    return items


def show_notes(st, notes: list[str]) -> None:
    """The tools' caveats, under every answer, in a closed expander: one click away even
    when the model leaves them out (7 Nov 2026: incident 911's 'read off the scan by a
    person' was dropped once). Closed because the answer usually says them already, in
    plainer words; the tools' wording is written for the model and names the trap-list
    item, which is what an auditor wants to see."""
    if notes:
        with st.expander(f"Caveats from the data ({len(notes)}), as the tools gave them"):
            st.markdown("\n".join(f"- {n}" for n in notes))


def img_html(item: dict) -> str:
    """The photo as an <img> with the bytes inside it (a data URL) and its caption.

    Not st.image: that keeps the bytes in the server's memory and gives the browser a
    /media/... link to fetch separately. On Cloud Run that second request can miss (another
    or restarted container, media released after a rerun, a tab from before a redeploy)
    and the photo shows broken; seen on the live page, 7 Nov 2026. A data URL travels with
    the page."""
    import base64
    import html

    mime = item.get("mime") or "image/jpeg"
    if mime not in ("image/jpeg", "image/png", "image/webp"):
        mime = "image/jpeg"
    data = base64.b64encode(item["bytes"]).decode("ascii")
    cap = html.escape(item.get("caption") or "")
    return (f'<figure style="margin:0 0 1rem 0"><img src="data:{mime};base64,{data}" '
            f'alt="{cap}" style="max-width:100%;height:auto;border:1px solid #ddd"/>'
            f'<figcaption style="font-size:0.85rem;color:#666">{cap}</figcaption></figure>')


def show_photos(st, items: list[dict]) -> None:
    if not items:
        return
    with st.expander(f"Photo{'s' if len(items) > 1 else ''} ({len(items)})", expanded=True):
        for it in items:
            if "bytes" in it:
                st.markdown(img_html(it), unsafe_allow_html=True)
            else:
                st.caption(it["note"])


def cost_line(usage: dict) -> str:
    """Under each answer: what the question took. The cost is what the LiteLLM proxy
    charged (x-litellm-response-cost); 'at least' when a call came back without one."""
    n = usage.get("model_calls", 0)
    if not n:
        return "No model calls: answered in code."
    calls = f"{n} model call{'s' if n != 1 else ''}"
    tokens = f"{usage.get('prompt_tokens', 0) + usage.get('completion_tokens', 0):,} tokens"
    cost = usage.get("cost_usd") or 0.0
    if not usage.get("cost_complete", True):
        return f"{calls}, {tokens}, at least ${cost:.4f} (a call came back without a cost)"
    return f"{calls}, {tokens}, ${cost:.4f}"


def session_line(spent: float, questions: int) -> str:
    return f"This session: ${spent:.4f} over {questions} question{'s' if questions != 1 else ''}"


DISPLAY_KEYS = ("role", "text", "sources", "notes", "cost")   # no photos, no trace


def kept_question(text: str) -> str:
    """A question as it may be stored or redrawn: as typed, or, if the guardrail refuses it,
    only the placeholder ask() puts in `messages`. A refused question can hold a staff name
    or an injection; the page used to save it as typed in the display copy (found 9 Nov
    2026, while adding the sidebar's list of saved conversations)."""
    v = app.guardrail.check_input(text)
    return text if v.allowed else f"[question withheld by the guardrail: {v.rule}]"


def _kept(m: dict) -> dict:
    if m.get("role") == "user" and isinstance(m.get("text"), str):
        return {**m, "text": kept_question(m["text"])}
    return m


def display_copy(shown: list[dict]) -> list[dict]:
    """What is saved of the page's display: the text and what was shown under it. Photos
    are left out (large, and re-fetchable from the database), and so is the trace. A
    question the guardrail refuses is saved only as its placeholder (kept_question)."""
    return [{k: m[k] for k in DISPLAY_KEYS if m.get(k) not in (None, [], "")}
            for m in map(_kept, shown)]


def restored(loaded) -> tuple[list[dict], list[dict]] | None:
    """(messages, shown) for a conversation loaded by sessions.SessionStore, the system
    prompt fresh from code; None if nothing was found. Questions go through kept_question
    again, so a row saved before that existed is cleaned when it is drawn."""
    if not (loaded.ok and loaded.found):
        return None
    shown = [_kept(m) for m in loaded.display if isinstance(m, dict) and m.get("role") in
             ("user", "assistant") and isinstance(m.get("text"), str)]
    return app.new_conversation() + loaded.messages, shown


RECENT = 3                       # saved conversations listed in the sidebar


def ago(when, now: datetime | None = None) -> str:
    """'just now', '5 min ago', '3 h ago', '2 d ago' for a UTC time from the store."""
    if isinstance(when, str):
        try:
            when = datetime.fromisoformat(when)
        except ValueError:
            return ""
    if not isinstance(when, datetime):
        return ""
    now = now or datetime.now(timezone.utc).replace(tzinfo=None)
    s = (now - when.replace(tzinfo=None)).total_seconds()
    if s < 60:
        return "just now"
    if s < 3600:
        return f"{int(s // 60)} min ago"
    if s < 86400:
        return f"{int(s // 3600)} h ago"
    return f"{int(s // 86400)} d ago"


_MD = re.compile(r"([\\`*_{}\[\]<>()#+\-.!|~$])")


def md_plain(text: str) -> str:
    """Text for a Streamlit label, which reads Markdown (and $...$ as maths): escaped, so
    a title shows exactly as stored."""
    return _MD.sub(r"\\\1", text)


def recent_label(r, current_sid: str | None, now: datetime | None = None) -> str:
    """One line in the sidebar's list: the first question, how many, and when (or that it
    is the conversation on the page)."""
    when = "open now" if r.sid == current_sid else ago(r.updated_at, now)
    n = f"{r.turns} question{'s' if r.turns != 1 else ''}"
    return md_plain(f"{r.title} ({n}, {when})" if when else f"{r.title} ({n})")


def save_line(store_on: bool, why: str | None, save_error: str | None) -> tuple[bool, str]:
    """(ok, sidebar text) for whether this conversation is being kept."""
    if not store_on:
        return False, f"Conversations aren't being saved ({why}). This one lasts until the page closes."
    if save_error:
        return False, f"This conversation isn't being saved right now: {save_error}."
    return True, "Saved after every answer. Keep this page's link to come back to it."


def password_ok(typed: str, expected: str) -> bool:
    """Constant-time check of the page password."""
    return hmac.compare_digest(typed.encode(), expected.encode())


def trace_rows(events: list[dict]) -> list[dict]:
    """One table row per model call or tool call, in the order they happened."""
    rows = []
    for e in events:
        kind = e.get("event")
        if kind == "chat_call":
            tools = ", ".join(e.get("tool_calls") or []) or "(answered)"
            cost = e.get("cost_usd")
            rows.append({"step": f"model, round {e['round']}",
                         "detail": f"asked for: {tools}"
                                   + (f" (${cost:.4f})" if cost is not None else ""),
                         "seconds": round(e["ms"] / 1000, 1)})
        elif kind == "tool_call":
            state = "ok" if e.get("ok") else f"refused: {e.get('error_code')}"
            rows.append({"step": f"tool, round {e['round']}",
                         "detail": f"{e['tool']} {e['arguments']} -> {state}",
                         "seconds": round(e["ms"] / 1000, 2)})
        elif kind == "chat_error":
            rows.append({"step": f"model, round {e['round']}", "detail": f"failed: {e['error']}",
                         "seconds": None})
        elif kind == "clarification_returned":
            rows.append({"step": "app", "detail": "tool asked a question; passed to the user",
                         "seconds": None})
        elif kind == "max_rounds_exceeded":
            rows.append({"step": "app", "detail": "stopped: too many tool calls", "seconds": None})
        elif kind == "input_refused":
            rows.append({"step": "guardrail", "seconds": None,
                         "detail": f"question refused in code ({e.get('rule')}: "
                                   f"{e.get('reason')}); the model was not called"})
        elif kind == "guard_not_ready":
            rows.append({"step": "guardrail", "seconds": None,
                         "detail": "refused: the staff name list isn't loaded (fail closed)"})
        elif kind == "output_blocked":
            rows.append({"step": "guardrail", "seconds": None,
                         "detail": f"answer replaced before it was shown ({e.get('rule')}: "
                                   f"{e.get('reason')})"})
    return rows


def main() -> None:
    import streamlit as st

    st.set_page_config(page_title="JME maintenance assistant", page_icon=None)
    st.title("JME maintenance assistant")
    st.caption("Answers come only from the shop's own data, through fixed tools, "
               "with the sources shown.")

    expected = os.environ.get("APP_PASSWORD")
    if expected and not st.session_state.get("authed"):
        typed = st.text_input("Password", type="password")
        if typed and password_ok(typed, expected):
            st.session_state.authed = True
            st.rerun()
        if typed:
            st.error("Wrong password.")
        st.stop()

    import guardrail
    try:
        guardrail.require_names()              # fail closed: no page without the name list
    except guardrail.GuardNotReady as e:
        st.error(str(e))
        st.stop()

    @st.cache_resource
    def connect():
        import agent_tools as at
        return at.connect(), app.build_client()

    try:
        db, client = connect()
    except SystemExit as e:           # build_client exits with a readable message
        st.error(str(e))
        st.stop()
    except Exception as e:
        st.error(f"Couldn't connect as the agent user: {e}")
        st.stop()

    import spend

    @st.cache_data(ttl=30, show_spinner=False)
    def key_budget():
        return spend.key_spend()                   # never raises; cached 30 s

    import sessions

    @st.cache_resource
    def session_store():
        store, why = sessions.store_from_env()    # never raises
        if store:
            store.purge()                          # retention, once per process start
        return store, why

    store, store_why = session_store()

    def start_fresh():
        st.session_state.messages = app.new_conversation()
        st.session_state.shown = []   # what to draw: role, text, sources, trace
        st.session_state.sid = sessions.new_session_id()
        st.session_state.save_error = None
        st.query_params["session"] = st.session_state.sid

    if "messages" not in st.session_state:        # a new page load, or the app restarted
        sid = st.query_params.get("session")      # read before start_fresh replaces it
        start_fresh()                             # a new id, unless the link's loads below:
        if store and sessions.valid_id(sid):
            loaded = store.load(sid)
            back = restored(loaded)
            if back:
                st.session_state.messages, st.session_state.shown = back
                st.session_state.sid = sid
                st.query_params["session"] = sid
            elif not loaded.ok:
                st.session_state.save_error = loaded.error

    with st.sidebar:
        st.subheader("Try")
        picked = None
        for q in EXAMPLES:
            if st.button(q, use_container_width=True):
                picked = q
        if st.button("New conversation", use_container_width=True):
            start_fresh()
            st.session_state.spent, st.session_state.questions = 0.0, 0
            st.rerun()
        st.caption(f"Model: {app.MODEL}")
        save_box = st.empty()                      # is this conversation being kept (#5)

    def show_saved():
        ok, text = save_line(store is not None, store_why, st.session_state.get("save_error"))
        (save_box.caption if ok else save_box.warning)(text)

    show_saved()

    def open_saved(sid: str) -> None:
        """Switch the page to a saved conversation, as if its link had been opened."""
        loaded = store.load(sid)
        back = restored(loaded)
        if back:
            st.session_state.messages, st.session_state.shown = back
            st.session_state.sid = sid
            st.session_state.save_error = None
            st.query_params["session"] = sid
            st.session_state.spent, st.session_state.questions = 0.0, 0
        else:
            st.session_state.save_error = loaded.error or "that conversation is no longer saved"
        st.rerun()

    if store:
        with st.sidebar:
            # The newest saved conversations (#5). Titles come from `messages`, where a
            # refused question is only its placeholder. Read once per run: one that is
            # saved by this run's answer shows from the next click on.
            st.subheader("Recent conversations")
            recent = store.recent(RECENT)          # never raises
            if recent is None:
                st.caption("Couldn't list saved conversations right now.")
            elif not recent:
                st.caption("No saved conversations yet.")
            for r in recent or []:
                here = r.sid == st.session_state.sid
                if st.button(recent_label(r, st.session_state.sid), key=f"recent_{r.sid}",
                             use_container_width=True, disabled=here):
                    open_saved(r.sid)
    with st.sidebar:
        # Spend (#7): this session from each call's cost header, exact and immediate; the
        # key's total against its cap from the proxy (about a minute behind).
        st.subheader("Spend")
        spend_box = st.empty()                     # filled now, and again after an answer

    def show_spend():
        with spend_box.container():
            st.caption(session_line(st.session_state.get("spent", 0.0),
                                    st.session_state.get("questions", 0)))
            ks = key_budget()
            (st.warning if ks.warn or not ks.ok else st.caption)(spend.budget_line(ks))

    show_spend()

    for m in st.session_state.shown:
        with st.chat_message(m["role"]):
            st.write(m["text"])
            if m.get("cost"):
                st.caption(m["cost"])
            if m.get("sources"):
                st.markdown("**Sources**\n" + "\n".join(f"- {s}" for s in m["sources"]))
            show_notes(st, m.get("notes") or [])
            show_photos(st, m.get("photos") or [])
            if m.get("trace"):
                with st.expander("What happened"):
                    st.table(m["trace"])

    question = st.chat_input("Ask about a machine, an incident or an SOP") or picked
    if not question:
        return

    st.session_state.shown.append({"role": "user", "text": question})
    with st.chat_message("user"):
        st.write(question)
    with st.chat_message("assistant"):
        lg, handler = trace_logger(log_to_file=True)
        raw: list[dict] = []
        tool_notes: list[str] = []
        usage: dict = {}
        with st.spinner("Asking the model and checking the data..."):
            answer, sources = app.ask(db, client, st.session_state.messages, question,
                                      logger=lg, raw_sources=raw, notes=tool_notes,
                                      usage=usage)
            photos = photo_items(db, raw)
            notes = app.format_notes(tool_notes)
        st.session_state.spent = st.session_state.get("spent", 0.0) + (usage.get("cost_usd") or 0)
        st.session_state.questions = st.session_state.get("questions", 0) + 1
        key_budget.clear()                         # re-read the key's spend from the proxy
        show_spend()                               # and redraw the sidebar with this question
        rows = trace_rows(handler.events)
        cost = cost_line(usage)
        st.write(answer)
        st.caption(cost)
        if sources:
            st.markdown("**Sources**\n" + "\n".join(f"- {s}" for s in sources))
        show_notes(st, notes)
        show_photos(st, photos)
        if rows:
            with st.expander("What happened", expanded=True):
                st.table(rows)
    st.session_state.shown.append({"role": "assistant", "text": answer,
                                   "sources": sources, "notes": notes, "photos": photos,
                                   "trace": rows, "cost": cost})
    if store:                                      # keep it for a restart (#5); never raises
        _, st.session_state.save_error = store.save(
            st.session_state.sid, st.session_state.messages,
            display_copy(st.session_state.shown))
        show_saved()


if __name__ == "__main__":
    main()